import { start } from './src/start/start.mjs';

const build = new start();

build.main();